package com.md5qat.mod;
import android.app.*;import android.os.*;import android.graphics.PixelFormat;import android.view.*;import android.widget.*;
public class OverlayService extends Service{
 WindowManager wm; TextView b;
 public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);b=new TextView(this);b.setText("MD5");b.setTextSize(20);b.setGravity(Gravity.CENTER);WindowManager.LayoutParams p=new WindowManager.LayoutParams(120,80,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.RIGHT;p.y=300;wm.addView(b,p);}
 public IBinder onBind(android.content.Intent i){return null;}
}